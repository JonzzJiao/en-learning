function ChatMessage({ message, onReplay }) {
  const { text, translation, sender } = message;

  // 根据消息发送者设置不同的样式
  const messageClasses = {
    user: "bg-indigo-100 ml-auto",
    ai: "bg-white border border-gray-200 mr-auto",
    system: "bg-red-100 mx-auto text-center"
  };

  // 判断是否是AI消息，显示翻译和重放按钮
  const isAiMessage = sender === 'ai';

  return (
    <div className={`rounded-lg p-4 max-w-[80%] ${messageClasses[sender]}`}>
      {/* 消息内容 */}
      <p className="text-gray-800">{text}</p>
      
      {/* 如果是AI消息，显示翻译 */}
      {isAiMessage && translation && (
        <p className="mt-2 text-gray-600 border-t pt-2">{translation}</p>
      )}
      
      {/* 如果是AI消息，显示重放语音按钮 */}
      {isAiMessage && onReplay && (
        <button
          onClick={onReplay}
          className="mt-2 text-indigo-600 hover:text-indigo-800 flex items-center text-sm"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
          </svg>
          重新播放语音
        </button>
      )}
    </div>
  );
}

export default ChatMessage; 
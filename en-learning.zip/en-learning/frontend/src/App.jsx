import { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import ChatInput from './components/ChatInput';
import ChatMessage from './components/ChatMessage';

function App() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);

  // 自动滚动到最新消息
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 检查API服务器状态
  useEffect(() => {
    const checkServerStatus = async () => {
      try {
        const response = await axios.get('/api/health');
        console.log('服务器状态:', response.data);
        if (response.data.status === 'ok') {
          setError(null);
        }
      } catch (error) {
        console.error('服务器连接失败:', error);
        setError('无法连接到后端服务器，请确保服务器已启动。');
      }
    };
    
    checkServerStatus();
  }, []);

  // 发送消息到后端
  const handleSendMessage = async (text) => {
    if (!text.trim()) return;
    
    // 添加用户消息到列表
    const userMessage = {
      id: Date.now(),
      text,
      sender: 'user',
    };
    
    setMessages(prev => [...prev, userMessage]);
    setLoading(true);
    setError(null);
    
    try {
      // 发送请求到后端
      const response = await axios.post('/api/chat', { message: text });
      
      // 检查响应中是否有错误消息
      if (response.data.error) {
        throw new Error(response.data.error);
      }
      
      // 添加AI回复到列表
      const aiMessage = {
        id: Date.now() + 1,
        text: response.data.english,
        translation: response.data.chinese,
        sender: 'ai',
      };
      
      setMessages(prev => [...prev, aiMessage]);
      
      // 朗读英文回复
      speakText(response.data.english);
    } catch (error) {
      console.error('Error sending message:', error);
      
      // 错误消息的文本
      let errorText = '抱歉，发生了错误，请稍后再试。';
      
      // 如果有详细的错误信息，使用它
      if (error.response?.data?.error) {
        errorText = `错误: ${error.response.data.error}`;
      } else if (error.message) {
        errorText = `错误: ${error.message}`;
      }
      
      // 添加错误消息
      const errorMessage = {
        id: Date.now() + 1,
        text: errorText,
        sender: 'system',
      };
      
      setMessages(prev => [...prev, errorMessage]);
      setError(errorText);
    } finally {
      setLoading(false);
    }
  };

  // 使用浏览器的语音合成API朗读文本
  const speakText = (text) => {
    if (!window.speechSynthesis) {
      console.error('浏览器不支持语音合成API');
      return;
    }

    // 停止当前正在播放的语音
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 0.9; // 语速稍慢，便于学习
    
    window.speechSynthesis.speak(utterance);
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* 头部 */}
      <header className="bg-indigo-600 py-4 shadow-md">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-bold text-white">Gemini 英语学习助手</h1>
        </div>
      </header>
      
      {/* 错误提示 */}
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* 消息区域 */}
      <main className="flex-1 overflow-auto bg-gray-50 p-4">
        <div className="container mx-auto max-w-3xl">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[50vh] text-gray-500">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 mb-4 text-indigo-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
              </svg>
              <p className="text-xl">开始对话，提高你的英语水平！</p>
              <p className="mt-2">输入中文或英文，AI将以英文回复并附带中文翻译</p>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map(message => (
                <ChatMessage
                  key={message.id}
                  message={message}
                  onReplay={message.sender === 'ai' ? () => speakText(message.text) : null}
                />
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>
      </main>
      
      {/* 输入区域 */}
      <footer className="bg-white border-t p-4">
        <div className="container mx-auto max-w-3xl">
          <ChatInput onSendMessage={handleSendMessage} loading={loading} />
        </div>
      </footer>
    </div>
  );
}

export default App; 
# Gemini 英语学习助手 - 前端

## 项目概述

这是一个基于 React 和 Vite 构建的 Gemini 英语学习助手前端。该应用通过 Google Gemini API 提供英语学习相关服务，包括对话练习、单词解释、语法分析、翻译等功能。

## 快速开始

1. **安装依赖**
   ```bash
   npm install
   ```

2. **启动开发服务器**
   ```bash
   npm run dev
   ```

3. **构建生产版本**
   ```bash
   npm run build
   ```

4. **预览生产版本**
   ```bash
   npm run preview
   ```

## 技术栈

- **React**: 用户界面库
- **Vite**: 构建工具和开发服务器
- **Tailwind CSS**: 样式框架
- **Marked**: Markdown 解析库
- **Highlight.js**: 代码高亮

## 目录结构

- `src/`: 源代码目录
  - `components/`: React 组件
    - `Chat.jsx`: 聊天界面组件
    - `FeatureCard.jsx`: 功能卡片组件
    - `Footer.jsx`: 页脚组件
    - `Header.jsx`: 页眉组件
    - `MarkdownRenderer.jsx`: Markdown 渲染器
  - `App.jsx`: 主应用组件
  - `main.jsx`: 应用入口点
  - `index.css`: 全局样式
- `public/`: 静态资源
  - `favicon.ico`: 网站图标

## 功能

1. **英语对话练习**: 模拟真实英语对话场景
2. **语法分析与修正**: 识别并纠正语法错误
3. **单词解释与示例**: 提供单词解释和使用示例
4. **翻译与对比**: 英中互译并解释区别
5. **文化背景解析**: 提供相关英语表达的文化背景

## 连接后端

应用默认连接到本地运行的后端服务：
- 开发环境: `http://localhost:5000/api`
- 生产环境: 相对路径 `/api`

如需更改后端 API 地址，请修改 `vite.config.js` 中的代理设置。

## 响应式设计

应用适配多种设备尺寸：
- 桌面电脑
- 平板电脑
- 移动设备

## 注意事项

- 确保后端服务正常运行并能够访问 Google Gemini API
- 如在中国大陆使用，可能需要为后端配置代理服务 
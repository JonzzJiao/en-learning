require('dotenv').config();
const axios = require('axios');

// 确保使用UTF-8编码
process.env.LANG = process.env.LANG || 'en_US.UTF-8';
process.env.LC_ALL = process.env.LC_ALL || 'en_US.UTF-8';

// 测试API服务器状态
async function testHealthEndpoint() {
  try {
    console.log('测试健康检查接口...');
    const response = await axios.get('http://localhost:3000/api/health');
    console.log('服务器状态:', response.data);
    return true;
  } catch (error) {
    console.error('无法连接到服务器:', error.message);
    return false;
  }
}

// 测试聊天功能 - 英文
async function testChatWithEnglish() {
  try {
    console.log('测试聊天接口 (英文输入)...');
    const response = await axios.post('http://localhost:3000/api/chat', {
      message: 'Hello, how are you today?'
    });
    console.log('响应:', response.data);
    return true;
  } catch (error) {
    console.error('聊天请求失败:', error.message);
    if (error.response) {
      console.error('错误详情:', error.response.data);
    }
    return false;
  }
}

// 测试聊天功能 - 中文
async function testChatWithChinese() {
  try {
    console.log('测试聊天接口 (中文输入)...');
    const response = await axios.post('http://localhost:3000/api/chat', {
      message: '你好，今天天气怎么样？'
    });
    console.log('响应:', response.data);
    return true;
  } catch (error) {
    console.error('聊天请求失败:', error.message);
    if (error.response) {
      console.error('错误详情:', error.response.data);
    }
    return false;
  }
}

// 运行所有测试
async function runTests() {
  console.log('开始API测试...');
  
  // 测试健康状态接口
  const healthStatus = await testHealthEndpoint();
  if (!healthStatus) {
    console.error('健康检查失败，请确保服务器已启动。');
    return;
  }
  
  // 等待一秒
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // 测试英文聊天
  const englishStatus = await testChatWithEnglish();
  if (!englishStatus) {
    console.error('英文聊天测试失败');
  }
  
  // 等待一秒
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  // 测试中文聊天
  const chineseStatus = await testChatWithChinese();
  if (!chineseStatus) {
    console.error('中文聊天测试失败');
  }
  
  console.log('测试完成！');
  console.log(`健康检查: ${healthStatus ? '✅ 成功' : '❌ 失败'}`);
  console.log(`英文聊天: ${englishStatus ? '✅ 成功' : '❌ 失败'}`);
  console.log(`中文聊天: ${chineseStatus ? '✅ 成功' : '❌ 失败'}`);
}

// 运行测试
runTests().catch(error => {
  console.error('测试过程中出错:', error);
}); 
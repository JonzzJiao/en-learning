require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { setGlobalDispatcher, ProxyAgent } = require("undici"); 

// 检查API密钥是否存在
if (!process.env.GEMINI_API_KEY) {
  console.error('错误: GEMINI_API_KEY 环境变量未设置');
  process.exit(1);
}

// 如果设置了代理环境变量，配置全局代理
if (process.env.HTTP_PROXY || process.env.HTTPS_PROXY) {
  const proxy = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
  const dispatcher = new ProxyAgent({ uri: new URL(proxy).toString() });
  setGlobalDispatcher(dispatcher); 
  console.log(`使用代理: ${proxy}`);
  
  // 尝试设置全局代理
  try {
    // 设置环境变量，许多 Node.js 库会读取这些变量
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // 在使用自签名证书的代理时可能需要
    
    // 如果需要更复杂的代理配置，可以使用 https-proxy-agent 包
    console.log('代理环境变量已配置，某些库会自动使用这些代理设置');
  } catch (proxyError) {
    console.error('配置代理时出错:', proxyError);
  }
}

// 确保使用UTF-8编码
process.env.LANG = process.env.LANG || 'en_US.UTF-8';
process.env.LC_ALL = process.env.LC_ALL || 'en_US.UTF-8';

// 初始化 Gemini API 客户端
console.log(`使用 API 密钥: ${process.env.GEMINI_API_KEY.substring(0, 8)}...`);
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// 使用更稳定的模型名称 - 从example.js降级到更稳定的公开版本
// 如果官方示例中的实验模型不可用，降级到稳定版本
const modelName = "gemini-2.5-pro-exp-03-25"; // 使用更稳定的公开模型

// 创建生成配置 - 与example.js不同，使用更保守的参数
const generationConfig = {
  temperature: 1,
  topP: 0.95,
  topK: 64,
  maxOutputTokens: 65536,
  responseModalities: [
  ],
  responseMimeType: "text/plain",
};

// 初始化Express应用
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// 健康检查路由
app.get('/api/health', (req, res) => {
  try {
    // 检查API能否连接
    const testModel = genAI.getGenerativeModel({ model: modelName });
    testModel.countTokens("test")
      .then(() => {
        res.status(200).json({ 
          status: 'ok', 
          message: 'Server is running and API connection is working',
          apiKeyConfigured: !!process.env.GEMINI_API_KEY,
          modelName: modelName,
          usingProxy: !!(process.env.HTTP_PROXY || process.env.HTTPS_PROXY),
          nodeVersion: process.version
        });
      })
      .catch(error => {
        res.status(200).json({ 
          status: 'warning', 
          message: 'Server is running but API connection is not working',
          error: error.message,
          apiKeyConfigured: !!process.env.GEMINI_API_KEY,
          modelName: modelName,
          usingProxy: !!(process.env.HTTP_PROXY || process.env.HTTPS_PROXY),
          nodeVersion: process.version
        });
      });
  } catch (error) {
    res.status(500).json({ 
      status: 'error', 
      message: 'Server error when testing API connection',
      error: error.message
    });
  }
});

// 聊天路由
app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: '缺少消息内容' });
    }

    console.log(`收到消息: "${message}"`);

    try {
      // 创建生成模型（不使用聊天会话API，改用直接生成内容）
      const model = genAI.getGenerativeModel({ model: modelName });
      
      // 构建提示词 - 使用英文指令避免编码问题
      const prompt = `
You are an English learning assistant. Based on the user's input, generate a natural English response and provide an accurate Chinese translation.
Your response should:
1. Respond in clear, correct English to the user's question or conversation
2. Then provide an accurate Chinese translation of your English response
3. If the user's input contains grammar or expression errors, use the correct expression in your English response and explain more natural ways to say it in your Chinese translation (if applicable)
4. Keep your response concise and friendly, with about 3-5 sentences per answer

Your response must follow this JSON format exactly (no extra text):
{
  "english": "Your English response here",
  "chinese": "Your Chinese translation here"
}

User message: ${message}
`;

      console.log('正在调用 Gemini API...');
      
      // 添加超时处理
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('请求超时')), 30000); // 30秒超时
      });
      
      // 使用直接生成而不是聊天会话API
      const generatePromise = model.generateContent(prompt);
      
      // 使用Promise.race实现超时处理
      const result = await Promise.race([generatePromise, timeoutPromise]);
      const text = result.response.text();
      
      console.log('Gemini API 响应成功');
      
      try {
        // 尝试解析JSON响应
        // 去除可能存在的markdown代码块标记
        const cleanedText = text.replace(/^```json\n|\n```$/g, '');
        const parsedResponse = JSON.parse(cleanedText);
        
        return res.status(200).json(parsedResponse);
      } catch (parseError) {
        console.error('解析响应时出错:', parseError);
        console.log('原始响应:', text);
        
        // 如果无法解析，尝试通过正则匹配获取英文和中文内容
        const englishMatch = text.match(/"english":\s*"([^"]+)"/);
        const chineseMatch = text.match(/"chinese":\s*"([^"]+)"/);
        
        if (englishMatch && chineseMatch) {
          return res.status(200).json({
            english: englishMatch[1],
            chinese: chineseMatch[1]
          });
        }
        
        // 如果还是无法解析，但有文本，尝试将其分割为英文和中文部分
        if (text.trim().length > 0) {
          // 假设文本的前半部分是英文，后半部分是中文
          const lines = text.split('\n').filter(line => line.trim().length > 0);
          
          if (lines.length >= 2) {
            // 提取可能的英文部分和中文部分
            let englishPart = '';
            let chinesePart = '';
            
            // 检查每行，看是否含有中文字符
            for (const line of lines) {
              if (/[\u4e00-\u9fa5]/.test(line)) {
                // 包含中文字符，添加到中文部分
                chinesePart += line + ' ';
              } else {
                // 不包含中文字符，添加到英文部分
                englishPart += line + ' ';
              }
            }
            
            return res.status(200).json({
              english: englishPart.trim() || "Response was not in expected format",
              chinese: chinesePart.trim() || "回复格式不符合预期"
            });
          }
        }
        
        // 如果还是无法解析，返回原始响应
        return res.status(200).json({
          english: "I'm sorry, I couldn't process your message properly.",
          chinese: "抱歉，我无法正确处理您的消息。"
        });
      }
    } catch (apiError) {
      console.error('调用 Gemini API 时出错:', apiError);
      
      // 生成友好的错误消息
      let errorMessage = '与 AI 服务通信时出错';
      if (apiError.message === '请求超时') {
        errorMessage = 'API 请求超时，请稍后再试';
      } else if (apiError.message.includes('API key')) {
        errorMessage = 'API 密钥无效或已过期';
      } else if (apiError.message.includes('ByteString') || apiError.message.includes('character')) {
        errorMessage = '字符编码问题，尝试使用英文提问';
        // 如果遇到编码错误，尝试提供一个默认响应
        return res.status(200).json({
          english: "I'm sorry, there was a character encoding issue. Could you try again with simpler text?",
          chinese: "抱歉，遇到了字符编码问题。您能否尝试使用更简单的文字再试一次？"
        });
      } else if (apiError.message.includes('fetch failed')) {
        errorMessage = '网络连接问题，可能需要使用代理访问 Google API';
      } else if (apiError.message.includes('not found')) {
        errorMessage = '模型不存在或不可用，请尝试使用其他模型名称';
      }
      
      return res.status(500).json({ 
        error: errorMessage,
        details: apiError.message,
        stack: apiError.stack
      });
    }
  } catch (error) {
    console.error('处理聊天请求时出错:', error);
    res.status(500).json({ 
      error: '服务器内部错误',
      message: error.message,
      stack: error.stack
    });
  }
});

// 启动服务器
app.listen(PORT, () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
  console.log(`Node.js版本: ${process.version}`);
  console.log(`使用模型: ${modelName}`);
  console.log(`API 密钥配置状态: ${process.env.GEMINI_API_KEY ? '已配置' : '未配置'}`);
  console.log(`代理配置状态: ${(process.env.HTTP_PROXY || process.env.HTTPS_PROXY) ? '已配置' : '未配置'}`);
}); 
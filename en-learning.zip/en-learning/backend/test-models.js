require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');

// 确保使用UTF-8编码
process.env.LANG = process.env.LANG || 'en_US.UTF-8';
process.env.LC_ALL = process.env.LC_ALL || 'en_US.UTF-8';

// 检查API密钥是否存在
if (!process.env.GEMINI_API_KEY) {
  console.error('错误: GEMINI_API_KEY 环境变量未设置');
  process.exit(1);
}

// 初始化 Gemini API 客户端
console.log(`使用 API 密钥: ${process.env.GEMINI_API_KEY.substring(0, 8)}...`);
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// 要测试的模型列表
const modelsToTest = [
  "gemini-pro",
  "gemini-1.5-pro-latest",
  "gemini-1.5-pro",
  "gemini-1.0-pro"
];

// 测试特定模型
async function testModel(modelName) {
  console.log(`\n正在测试模型: ${modelName}`);
  
  try {
    // 创建生成模型
    const model = genAI.getGenerativeModel({ 
      model: modelName,
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 1024,
      }
    });

    // 先测试一个简单的token计数（如果API密钥问题或连接问题，这里就会失败）
    try {
      console.log("测试API连接...");
      const tokenResult = await model.countTokens("Hello, how are you?");
      console.log(`Token计数成功: ${tokenResult.totalTokens} tokens`);
    } catch (tokenError) {
      console.error("Token计数失败:", tokenError.message);
      return { success: false, error: tokenError.message };
    }
    
    // 测试简单的英文文本生成
    try {
      console.log("测试英文内容生成...");
      const englishPrompt = "What is the capital of France?";
      const englishResult = await model.generateContent(englishPrompt);
      const englishText = englishResult.response.text();
      console.log(`英文生成成功。回复: "${englishText.substring(0, 50)}${englishText.length > 50 ? '...' : ''}"`);
    } catch (englishError) {
      console.error("英文生成失败:", englishError.message);
      return { success: false, error: englishError.message };
    }
    
    // 测试简单的中文文本生成
    try {
      console.log("测试中文内容生成...");
      const chinesePrompt = "法国的首都是什么?";
      const chineseResult = await model.generateContent(chinesePrompt);
      const chineseText = chineseResult.response.text();
      console.log(`中文生成成功。回复: "${chineseText.substring(0, 50)}${chineseText.length > 50 ? '...' : ''}"`);
    } catch (chineseError) {
      console.error("中文生成失败:", chineseError.message);
      return { success: false, error: chineseError.message };
    }
    
    return { success: true };
  } catch (error) {
    console.error(`测试模型 ${modelName} 时出错:`, error.message);
    return { success: false, error: error.message };
  }
}

// 运行所有测试
async function runTests() {
  console.log('开始Gemini模型测试...');
  console.log(`Node.js版本: ${process.version}`);
  console.log(`环境变量设置: LANG=${process.env.LANG}, LC_ALL=${process.env.LC_ALL}`);
  console.log(`代理设置: HTTP_PROXY=${process.env.HTTP_PROXY || '未设置'}, HTTPS_PROXY=${process.env.HTTPS_PROXY || '未设置'}`);
  
  const results = {};
  
  // 测试每个模型
  for (const modelName of modelsToTest) {
    results[modelName] = await testModel(modelName);
  }
  
  // 打印测试结果
  console.log("\n测试结果汇总:");
  console.log("=================");
  
  for (const [modelName, result] of Object.entries(results)) {
    console.log(`${modelName}: ${result.success ? '✅ 成功' : '❌ 失败'}`);
    if (!result.success && result.error) {
      console.log(`   错误: ${result.error}`);
    }
  }
  
  // 根据测试结果提供建议
  const workingModels = Object.entries(results)
    .filter(([_, result]) => result.success)
    .map(([modelName]) => modelName);
  
  if (workingModels.length > 0) {
    console.log("\n推荐使用的模型:", workingModels[0]);
    console.log("请在server.js中更新modelName为上述值");
  } else {
    console.log("\n没有任何模型测试成功。可能的原因:");
    console.log("1. API密钥无效或已过期");
    console.log("2. 网络连接问题，需要配置代理");
    console.log("3. API服务当前不可用");
    console.log("\n请检查您的API密钥和网络环境。");
  }
}

// 运行测试
runTests().catch(error => {
  console.error('测试过程中出错:', error);
}); 
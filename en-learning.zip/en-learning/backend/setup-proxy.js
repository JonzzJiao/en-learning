/**
 * 代理设置助手脚本
 * 
 * 这个脚本帮助用户自动配置代理设置，尤其适用于位于中国大陆等无法直接访问Google服务的地区。
 * 
 * 使用方法: node setup-proxy.js [代理URL]
 * 例如: node setup-proxy.js http://127.0.0.1:7890
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 从命令行获取代理URL，如果没有提供则使用默认值
const proxyUrl = process.argv[2] || 'http://127.0.0.1:7890';
const envFile = path.join(__dirname, '.env');

// 检查是否可以连接到Google服务
function checkConnection() {
  try {
    console.log('正在测试与Google服务的连接...');
    const result = execSync('curl -s -m 5 https://generativelanguage.googleapis.com', 
      { stdio: 'pipe', encoding: 'utf-8' });
    
    if (result && !result.includes('error')) {
      console.log('✅ 可以直接访问Google服务，不需要配置代理');
      return true;
    }
  } catch (error) {
    console.log('❌ 无法直接访问Google服务，需要配置代理');
    return false;
  }
  
  return false;
}

// 测试代理是否有效
function testProxy(proxy) {
  try {
    console.log(`正在测试代理 ${proxy}...`);
    execSync(`curl -s -m 10 -x ${proxy} https://generativelanguage.googleapis.com`, 
      { stdio: 'pipe', encoding: 'utf-8' });
    console.log(`✅ 使用代理 ${proxy} 可以访问Google服务`);
    return true;
  } catch (error) {
    console.log(`❌ 代理 ${proxy} 无效或无法连接到Google服务`);
    return false;
  }
}

// 更新.env文件
function updateEnvFile(proxy) {
  try {
    // 读取当前.env文件内容
    let envContent = '';
    if (fs.existsSync(envFile)) {
      envContent = fs.readFileSync(envFile, 'utf-8');
    }
    
    // 设置代理环境变量
    const proxyLines = [
      `# 代理设置 (自动配置于 ${new Date().toLocaleString()})`,
      `HTTP_PROXY=${proxy}`,
      `HTTPS_PROXY=${proxy}`
    ].join('\n');
    
    // 如果已经存在代理设置，则替换它们
    if (envContent.includes('HTTP_PROXY=') || envContent.includes('HTTPS_PROXY=')) {
      const proxyRegex = /(#.*代理设置.*\n)?(HTTP_PROXY=.*\n)?(HTTPS_PROXY=.*\n)?/g;
      envContent = envContent.replace(proxyRegex, '');
    }
    
    // 添加代理设置
    envContent = envContent.trim() + '\n\n' + proxyLines + '\n';
    
    // 写入文件
    fs.writeFileSync(envFile, envContent);
    console.log(`✅ 已成功将代理设置写入.env文件`);
    
    return true;
  } catch (error) {
    console.error(`❌ 更新.env文件时出错:`, error.message);
    return false;
  }
}

// 主函数
function main() {
  console.log('======= Gemini API 代理设置助手 =======');
  console.log(`当前工作目录: ${__dirname}`);
  
  // 检查是否存在.env文件
  if (!fs.existsSync(envFile)) {
    console.log(`❌ .env文件不存在。请先创建一个.env文件并设置GEMINI_API_KEY。`);
    return;
  }
  
  // 检查直接连接
  const canDirectConnect = checkConnection();
  if (canDirectConnect) {
    console.log('无需配置代理，您可以直接访问Google服务。');
    // 移除已有的代理设置
    let envContent = fs.readFileSync(envFile, 'utf-8');
    const proxyRegex = /(#.*代理设置.*\n)?(HTTP_PROXY=.*\n)?(HTTPS_PROXY=.*\n)?/g;
    envContent = envContent.replace(proxyRegex, '');
    fs.writeFileSync(envFile, envContent.trim() + '\n');
    console.log('已移除现有的代理设置。');
    return;
  }
  
  // 测试提供的代理
  const isProxyValid = testProxy(proxyUrl);
  if (!isProxyValid) {
    console.log(`提供的代理 ${proxyUrl} 无法访问Google服务。`);
    console.log('请检查代理地址是否正确，或尝试其他代理。');
    console.log('用法: node setup-proxy.js [代理URL]');
    console.log('例如: node setup-proxy.js http://127.0.0.1:7890');
    return;
  }
  
  // 更新.env文件
  const updateSuccess = updateEnvFile(proxyUrl);
  if (updateSuccess) {
    console.log('\n代理设置已成功配置！');
    console.log('现在您可以通过以下命令测试是否可以访问Gemini API:');
    console.log('> node test-api.js');
    console.log('或测试有效的模型:');
    console.log('> node test-models.js');
  }
}

// 执行主函数
main(); 
# Gemini 英语学习助手 - 后端

## 使用 Gemini API 的问题及解决方案

在使用 Google Gemini API 时，可能会遇到一些连接问题，特别是在中国大陆等地区。即使是 Google 官方提供的示例代码 `example.js` 也可能遇到 `fetch failed` 错误。本指南帮助您解决这些问题。

## 快速开始

1. **安装依赖**
   ```bash
   npm install
   ```

2. **配置 API 密钥**
   - 在 `.env` 文件中添加您的 Gemini API 密钥：
   ```
   GEMINI_API_KEY=您的密钥（以AIzaSy开头）
   ```

3. **测试连接并配置代理**（如需要）
   - 运行代理设置助手：
   ```bash
   node setup-proxy.js [代理URL]
   ```
   - 如果您在中国大陆，示例：
   ```bash
   node setup-proxy.js http://127.0.0.1:7890
   ```
   *注：上述命令假设您使用了 Clash 等代理工具，端口为 7890*

4. **测试可用模型**
   ```bash
   node test-models.js
   ```
   此命令会测试多个 Gemini 模型版本，并推荐使用能正常工作的版本。

5. **启动服务器**
   ```bash
   npm start
   ```

6. **测试 API**
   ```bash
   node test-api.js
   ```
   此命令会测试 API 的健康状态和聊天功能。

## 文件说明

- `server.js`：主服务器代码，负责处理 API 请求
- `setup-proxy.js`：代理设置助手，帮助配置访问 Google 服务的代理
- `test-models.js`：测试不同 Gemini 模型的可用性
- `test-api.js`：测试 API 的功能和连接状态
- `.env`：环境变量配置文件

## 常见问题

### 为什么官方示例代码也会出错？

1. **网络连接问题**：
   - 在中国大陆访问 Google 服务通常需要使用代理
   - 即使是官方示例代码，如果没有适当的网络环境，也会连接失败

2. **API 密钥问题**：
   - 示例使用 `process.env.GEMINI_API_KEY`，须确保此环境变量已设置

3. **模型可用性**：
   - 示例中使用的 `gemini-2.5-pro-exp-03-25` 是实验模型，可能不可用

4. **Node.js 版本兼容性**：
   - 错误信息显示您使用的是较新的 Node.js 版本，可能有兼容性问题

### 解决方案

我们已经实施了多项改进来解决这些问题：

1. **使用更稳定的模型**：
   - 我们从实验版本降级到更稳定的公开版本 `gemini-pro`
   - 提供了测试多个模型的脚本 `test-models.js`

2. **添加代理支持**：
   - 提供了代理配置助手 `setup-proxy.js`
   - 在服务器代码中增加了代理支持

3. **改进错误处理**：
   - 添加了详细的错误日志
   - 加强了健康检查接口

4. **简化API使用**：
   - 改用直接生成内容而不是聊天会话API，减少出错可能

## 需要进一步帮助？

请查阅项目根目录的 `TROUBLESHOOTING.md` 文件，获取更多故障排除建议。 
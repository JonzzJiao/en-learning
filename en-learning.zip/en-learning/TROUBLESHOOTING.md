# Gemini 英语学习助手 - 故障排除指南

本文档提供了使用 Gemini 英语学习助手时可能遇到的常见问题及其解决方案。

## 目录

1. [API 连接问题](#api-连接问题)
2. [模型响应问题](#模型响应问题)
3. [前端显示问题](#前端显示问题)
4. [中国大陆网络问题](#中国大陆网络问题)
5. [性能优化问题](#性能优化问题)

## API 连接问题

### 问题：出现 "fetch failed" 错误

**可能原因：**
- 网络连接问题
- API 密钥无效或未设置
- 模型版本不可用
- 防火墙或代理设置

**解决方案：**

1. **验证 API 密钥**
   - 确保 `.env` 文件中的 `GEMINI_API_KEY` 已正确设置
   - 验证 API 密钥格式是否正确（通常以 `AIzaSy` 开头）
   - 使用 `test-api.js` 测试 API 密钥：
     ```bash
     node test-api.js
     ```

2. **检查网络连接**
   - 使用 `setup-proxy.js` 测试连接：
     ```bash
     node setup-proxy.js
     ```
   - 确认能够访问 `https://generativelanguage.googleapis.com`

3. **测试不同模型版本**
   - 使用 `test-models.js` 测试多个模型版本：
     ```bash
     node test-models.js
     ```
   - 根据测试结果修改 `server.js` 中的模型版本

4. **配置代理**（尤其适用于中国大陆用户）
   - 在 `.env` 文件中设置 `HTTP_PROXY`：
     ```
     HTTP_PROXY=http://127.0.0.1:7890
     ```
   - 或者使用代理设置助手：
     ```bash
     node setup-proxy.js http://127.0.0.1:7890
     ```

### 问题：API 响应时间过长

**解决方案：**
- 减少生成内容的最大长度（修改 `server.js` 中的 `maxOutputTokens` 参数）
- 检查网络延迟（使用更快的网络或代理）
- 调整模型参数（减少 `temperature` 值，默认为 0.7）

## 模型响应问题

### 问题：生成的内容质量不高

**解决方案：**
- 调整 `temperature` 参数（更高的值增加创造性，更低的值提高一致性）
- 修改系统提示词（在 `server.js` 中编辑 `systemPrompt`）
- 测试不同的模型版本（使用 `test-models.js`）

### 问题：输出中文乱码

**可能原因：**
- 字符编码问题
- Content-Type 设置不正确

**解决方案：**
1. 确保 API 响应头设置正确：
   ```javascript
   res.setHeader('Content-Type', 'application/json; charset=utf-8');
   ```

2. 确保前端正确处理 UTF-8 编码：
   ```html
   <meta charset="UTF-8">
   ```

## 前端显示问题

### 问题：无法加载界面或功能不正常

**解决方案：**
1. 检查浏览器控制台是否有错误
2. 确保所有 npm 包已正确安装：
   ```bash
   cd frontend
   npm install
   ```
3. 确保后端服务正在运行：
   ```bash
   cd backend
   npm start
   ```
4. 检查 `vite.config.js` 中的代理设置是否正确

### 问题：语音合成不工作

**解决方案：**
1. 确认您的浏览器支持 Web Speech API
2. 检查浏览器是否允许网站使用语音合成功能
3. 尝试使用不同的浏览器（Chrome 通常支持最好）

## 中国大陆网络问题

### 问题：无法连接到 Google API

**解决方案：**
1. 设置 HTTP 代理：
   - 在 `.env` 文件中添加：
     ```
     HTTP_PROXY=http://127.0.0.1:7890
     ```
   - 确保代理服务器（如 Clash, V2Ray）正在运行

2. 使用代理设置助手：
   ```bash
   node setup-proxy.js http://127.0.0.1:7890
   ```

3. 检查代理设置是否生效：
   ```bash
   node test-api.js
   ```

### 问题：即使配置了代理，仍然无法连接

**解决方案：**
1. 确认代理服务器能正常访问 Google 服务
2. 检查 Node.js 是否正确使用代理环境变量（某些版本可能需要其他设置）
3. 尝试更改 DNS 设置或使用 DOH（DNS over HTTPS）

## 性能优化问题

### 问题：前端响应缓慢

**解决方案：**
1. 启用内容缓存（在 `server.js` 中添加适当的缓存头）
2. 对前端应用进行生产构建：
   ```bash
   cd frontend
   npm run build
   ```
3. 优化图像和静态资源

### 问题：后端内存使用高

**解决方案：**
1. 添加请求限制（使用 `express-rate-limit` 包）
2. 优化 API 调用（减少不必要的请求或合并请求）
3. 监控并调整 Node.js 内存参数

## 联系与支持

如果您遇到的问题未在本指南中列出，请：

1. 检查项目 GitHub 上的 Issues 页面
2. 提交新的 Issue 并详细描述您的问题
3. 包含错误日志、使用环境和复现步骤

## 更新日志

最后更新：2024 年 4 月 4 日 
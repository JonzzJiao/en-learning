# Gemini 英语学习助手

一个使用 Google Gemini 大型语言模型的英语学习应用程序，帮助用户进行英语对话练习、语法分析、单词解释等。

![Gemini 英语学习助手](./frontend/public/hero.png)

## ✨ 功能特点

- 🗣️ **对话练习**：模拟各种场景的英语对话
- 🔍 **语法分析**：识别并纠正语法错误，提供学习建议
- 📚 **单词解释**：详细解释单词含义，提供例句和用法
- 🔄 **英中互译**：提供精准翻译，并解释语言表达差异
- 🌍 **文化背景**：解释英语表达的文化背景和使用场景

## 🚀 快速开始

### 前提条件

- Node.js (建议 v18+)
- npm 或 yarn
- Google Gemini API 密钥 ([获取方法](https://ai.google.dev/tutorials/setup))

### 安装与配置

1. **克隆仓库**
   ```bash
   git clone https://github.com/yourusername/gemini-english-learning.git
   cd gemini-english-learning
   ```

2. **后端设置**
   ```bash
   cd backend
   npm install
   cp .env.example .env
   ```
   
   在 `.env` 文件中添加您的 Gemini API 密钥
   ```
   GEMINI_API_KEY=YOUR_API_KEY
   ```

3. **中国大陆用户的网络配置**
   
   如果您在中国大陆使用此应用，需要配置代理以访问 Google API：
   ```bash
   node setup-proxy.js http://127.0.0.1:7890
   ```
   *注：上述命令假设您使用了 Clash 等代理工具，端口为 7890*

4. **前端设置**
   ```bash
   cd ../frontend
   npm install
   ```

### 启动应用

1. **启动后端服务**
   ```bash
   cd backend
   npm start
   ```
   服务器将在 http://localhost:5000 上运行

2. **启动前端开发服务器**
   ```bash
   cd ../frontend
   npm run dev
   ```
   前端将在 http://localhost:5173 上运行

3. **访问应用**
   
   在浏览器中打开 http://localhost:5173

### 生产环境构建

```bash
cd frontend
npm run build
```

构建后的文件将位于 `frontend/dist` 目录下，可以部署到任何静态文件服务器上。

## 🔧 故障排除

如遇到问题，请查阅：
- [后端 README](./backend/README.md) - 包含 API 连接和代理设置指南
- [前端 README](./frontend/README.md) - 包含前端开发和配置指南
- [故障排除指南](./TROUBLESHOOTING.md) - 包含常见问题解决方案

## 📁 项目结构

```
gemini-english-learning/
├── backend/              # 后端 Node.js Express 服务
│   ├── server.js         # 主服务器文件
│   ├── setup-proxy.js    # 代理配置工具
│   ├── test-models.js    # 模型测试工具
│   └── test-api.js       # API 测试工具
│
├── frontend/             # React 前端应用
│   ├── public/           # 静态资源
│   └── src/              # 源代码
│       ├── components/   # React 组件
│       ├── App.jsx       # 主应用组件
│       └── main.jsx      # 应用入口点
│
└── TROUBLESHOOTING.md    # 故障排除指南
```

## 🛡️ 安全注意事项

- 切勿在公共仓库中提交您的 API 密钥
- 在生产环境中，确保您的 API 请求具有适当的速率限制和监控
- 考虑使用环境变量或密钥管理解决方案来管理敏感信息

## 📄 许可证

MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

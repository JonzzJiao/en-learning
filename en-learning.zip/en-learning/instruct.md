# 🧠 Gemini 英语学习助手

这是一个基于 Google Gemini 2.5 Pro 的 Web 应用程序，旨在通过交互式对话帮助用户学习英语。用户可以输入中文或英文句子，应用会利用 Gemini 生成标准的英文回答及其对应的中文翻译，并通过浏览器自带的语音合成功能朗读英文内容，同时在界面上显示中英文字幕。

## ✨ 核心功能

*   **用户输入:** 接收用户输入的中文或英文句子。
*   **AI 回复与翻译:** 调用 Gemini 2.5 Pro API 获取标准、自然的英文回答和准确的中文翻译。
*   **语音朗读:** 使用浏览器原生的 Web Speech API (`speechSynthesis`) 朗读生成的英文回答。
*   **双语字幕:** 在界面上清晰地展示英文回答和中文翻译。
*   **简洁界面:** 采用 Tailwind CSS 构建极简风格的用户界面。

## 🛠️ 技术栈

| 层级      | 技术                                   | 说明                                     |
| :-------- | :------------------------------------- | :--------------------------------------- |
| 🎨 **前端** | React + Vite                           | 用于构建用户界面，提供快速开发体验。       |
|           | Tailwind CSS                           | 提供原子化的 CSS 类，快速构建样式。          |
|           | Web Speech API (`speechSynthesis`)     | 实现浏览器原生的文本到语音功能。           |
| 🌐 **后端 API** | Node.js + Express (或 Python Flask)  | 接收前端请求，与 Gemini API 交互。         |
| 🤖 **AI 模型** | Google Gemini 2.5 Pro API            | 生成英文回答和中文翻译。                 |
| 🔒 **安全** | 环境变量 (`.env`)                     | 安全地存储 Gemini API Key。              |

## 🚀 运行项目

**1. 克隆仓库**

```bash
git clone <你的仓库地址>
cd <项目目录>
```

**2. 安装依赖**

*   **前端:** (假设前端代码在 `frontend` 目录)
    ```bash
    cd frontend
    npm install
    # 或者 yarn install / pnpm install
    ```
*   **后端:** (假设后端代码在 `backend` 目录)
    ```bash
    cd ../backend
    npm install
    # 或者 yarn install / pnpm install
    ```

**3. 配置环境变量**

*   在 **后端项目** 的根目录 (例如 `backend/`) 下创建一个名为 `.env` 的文件。
*   在 `.env` 文件中添加你的 Google AI Studio API Key：
    ```env
    GEMINI_API_KEY=YOUR_GOOGLE_AI_STUDIO_API_KEY
    ```
*   **⚠️ 重要:** 确保将 `.env` 文件添加到你的 `.gitignore` 文件中，以防止将 API Key 意外提交到版本控制系统。

**4. 启动服务**

*   **启动前端开发服务器:**
    ```bash
    cd ../frontend
    npm run dev
    # 或者 yarn dev / pnpm dev
    ```
*   **启动后端服务器:**
    ```bash
    cd ../backend
    npm start
    # 或者 node server.js (或其他启动命令)
    ```

**5. 访问应用**

在浏览器中打开 Vite 提供的本地开发地址 (通常是 `http://localhost:5173` 或类似地址)。

---

现在你可以开始使用 Gemini 英语学习助手了！

# Gemini 英语学习助手 - 开发指南

该文档为开发者提供 Gemini 英语学习助手的详细开发指南和贡献方式。

## 项目架构

项目采用前后端分离的架构，通过 API 进行通信：

```
gemini-english-learning/
├── backend/                 # Node.js 后端服务
│   ├── server.js            # 主服务器文件
│   ├── test-api.js          # API 测试工具
│   ├── test-models.js       # 模型测试工具
│   ├── setup-proxy.js       # 代理配置工具
│   ├── .env                 # 环境配置文件(本地开发)
│   └── .env.example         # 环境变量示例
│
├── frontend/                # React 前端应用
│   ├── public/              # 静态资源
│   │   └── favicon.ico      # 网站图标
│   ├── src/                 # 源代码
│   │   ├── components/      # React 组件
│   │   │   ├── Chat.jsx     # 聊天组件
│   │   │   ├── FeatureCard.jsx  # 功能卡片组件
│   │   │   ├── Footer.jsx   # 页脚组件
│   │   │   ├── Header.jsx   # 页眉组件
│   │   │   └── MarkdownRenderer.jsx  # Markdown渲染组件
│   │   ├── App.jsx          # 主应用组件
│   │   ├── main.jsx         # 应用入口点
│   │   └── index.css        # 全局样式
│   ├── index.html           # HTML模板
│   ├── vite.config.js       # Vite配置
│   └── tailwind.config.js   # Tailwind CSS配置
│
├── TROUBLESHOOTING.md      # 故障排除指南
├── README.md               # 项目说明文档
└── .gitignore              # Git忽略配置
```

## 技术栈详解

### 后端

- **Node.js**: 运行时环境
- **Express**: Web服务器框架
- **@google/generative-ai**: Google Gemini API客户端
- **dotenv**: 环境变量管理
- **cors**: 跨域资源共享
- **axios**: HTTP客户端（用于代理测试）
- **fs**: 文件系统操作（为代理配置）

### 前端

- **React**: UI库
- **Vite**: 构建工具
- **Tailwind CSS**: 样式框架
- **marked**: Markdown解析
- **highlight.js**: 代码高亮
- **Web Speech API**: 浏览器原生语音合成

## 核心功能实现

### 1. API通信流程

```
前端 -> 后端 -> Gemini API -> 后端 -> 前端
```

- 前端发送用户输入到后端 `/api/chat` 端点
- 后端使用系统提示词格式化请求并调用Gemini API
- 后端处理AI响应，提取英文和中文内容
- 前端接收响应并渲染结果，播放语音

### 2. 代理配置系统

为解决中国大陆用户的网络问题，我们实现了自动代理配置系统:

- `setup-proxy.js` 可测试直接连接和代理连接
- 自动更新 `.env` 文件中的代理设置
- 服务器代码根据环境变量配置代理

### 3. 模型测试系统

为应对不同模型版本的可用性问题:

- `test-models.js` 测试多个Gemini模型
- 自动推荐可用的最佳模型
- 通过环境变量轻松切换模型版本

## 设计决策说明

### 1. 前后端分离

**优势**:
- 更清晰的关注点分离
- 前端独立开发和部署
- 更好的代码组织和维护

### 2. 直接内容生成 vs. 聊天API

我们从使用 Gemini 的聊天API转向直接内容生成API:

**原因**:
- 更简单的错误处理
- 减少字符编码问题
- 更一致的格式化结果

### 3. 响应式设计

前端UI采用完全响应式设计:

- 使用Tailwind CSS的响应式类
- 针对移动设备优化的布局
- 适应不同屏幕尺寸的组件设计

## 贡献指南

希望为项目做出贡献? 请遵循以下步骤:

### 开发环境设置

1. Fork并克隆仓库
2. 安装依赖:
   ```bash
   # 后端
   cd backend
   npm install
   
   # 前端
   cd ../frontend
   npm install
   ```
3. 复制环境变量示例:
   ```bash
   cd ../backend
   cp .env.example .env
   ```
4. 添加你的Gemini API密钥到`.env`文件

### 代码风格

- 使用ESLint和Prettier保持代码风格一致
- 遵循组件化设计原则
- 为函数和复杂逻辑添加注释

### 提交PR流程

1. 创建特性分支: `git checkout -b feature/your-feature-name`
2. 进行更改并提交
3. 推送到你的fork: `git push origin feature/your-feature-name`
4. 创建Pull Request并描述你的更改

### 测试指南

提交PR前请确保:

1. 后端API正常工作:
   ```bash
   cd backend
   node test-api.js
   ```
2. 前端应用可正常编译和渲染
3. 应用在不同屏幕尺寸下显示正常
4. 所有主要功能保持正常工作

## 未来功能计划

- [ ] 添加语音输入功能
- [ ] 实现对话历史保存和恢复
- [ ] 添加更多专业英语学习场景
- [ ] 支持导出学习记录为PDF
- [ ] 实现用户登录和个性化设置
